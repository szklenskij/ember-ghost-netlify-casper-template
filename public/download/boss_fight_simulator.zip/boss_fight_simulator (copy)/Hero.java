package project;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;


public class Hero {

  int partySize = 0;

  private int heroStr;
  private int heroHp;
  private int heroMaxHp;
  private int heroId;
  private int heroHeal;
  private String heroClass;

  // Not implimented. Would be used to establish max class count within the party.
  //int knightNum = 0;
  //int wizardNum = 0;
  //int healerNum = 0;
  //int rogueNum = 0;
  //int barbarianNum = 0;
  //int rangerNum = 0;

  /** This method takes the player's imput and fills the Hero array with the
    * given hero's stats.
    */
  public Hero(int id) {

    heroId = id;

    // Knight
    if (heroId == 0) {
      heroStr = 10;
      heroHp = 50;
      heroMaxHp = 50;
      heroHeal = 1;
      heroClass = "Knight";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Wizard
    } else if (heroId == 1) {
      heroStr = 15;
      heroHp = 40;
      heroMaxHp = 40;
      heroHeal = 5;
      heroClass = "Wizard";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Healer
    } else if (heroId == 2) {
      heroStr = 2;
      heroHp = 45;
      heroMaxHp = 45;
      heroHeal = 15;
      heroClass = "Healer";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Rogue
    } else if (heroId == 3) {
      heroStr = 15;
      heroHp = 45;
      heroMaxHp = 45;
      heroHeal = 1;
      heroClass = "Rogue";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Barbarian
    } else if (heroId == 4) {
      heroStr = 8;
      heroHp = 55;
      heroMaxHp = 55;
      heroHeal = 1;
      heroClass = "Barbarian";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Ranger
    } else if (heroId == 5) {
      heroStr = 10;
      heroHp = 45;
      heroMaxHp = 45;
      heroHeal = 10;
      heroClass = "Ranger";
      System.out.println("\nYou have added the " + heroClass + " to your party.\n");

    // Should never be reached. Failsafe.
    } else {
      System.out.println("Invalid Hero ID.");
    }
  }

  public int getHeroId() {
    return heroId;
  }

  public int getHeroStr() {
    return heroStr;
  }

  public int getHeroHp() {
    return heroHp;
  }

  public int getHeroMaxHp() {
    return heroMaxHp;
  }

  public int getHeroHeal() {
    return heroHeal;
  }

  public String getHeroClass() {
    return heroClass;
  }

  // Do damage to hero
  public void bossDmg(int strDmg) {
    heroHp -= strDmg;
  }

  // Heal damage to hero
  public void healDmg(int groupHeal) {
    heroHp += groupHeal;
  }

  // Decrease a hero's strength
  public void dmgStr(int decrStr) {
    heroStr -= decrStr;
  }

  // Decrease a hero's maximum health
  public void dmgHealth(int decrHealth) {
    heroMaxHp -= decrHealth;
    //heroHpCap -= (decrHealth + 10);
  }

  // Set heroes' strength to 0, for if strength < 0
  public void strSetter() {
    heroStr = 0;
  }
}
