package project;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Boss {

  private ArrayList<Hero> party = new ArrayList<Hero>();
  private ArrayList<Boss> bossStats = new ArrayList<Boss>();

  private int bossId;
  private int bossHp;
  private int bossMaxHp;
  private int bossStr;
  private String bossName;
  Random random = new Random();
  int randHero = 4;
  int hitHero = random.nextInt(4);

  /** This method sets the values for one of three bosses, randomly chosen at
    * the beginning of the game.
    */
  public Boss() {

    bossId = random.nextInt(3);

    // Spider Queen
    if (bossId == 0) {
      bossName = "Spider Queen";
      bossHp = (random.nextInt(40) + 120);
      bossStr = 20;
      // [Developer text] System.out.println("The " + getBossName() + " was picked...");

    // Shadow Prince
    } else if (bossId == 1) {
      bossName = "Shadow Prince";
      bossHp = (random.nextInt(60) + 110);
      bossStr = 15;
      // [Developer text] System.out.println("The " + getBossName() + " was picked...");

    // Dragon Lord
    } else if (bossId == 2) {
      bossName = "Dragon Lord";
      bossHp = (random.nextInt(30) + 140);
      bossStr = 25;
      // [Developer text] System.out.println("The " + getBossName() + " was picked...");
    }
    // Ensures the boss's maxHp cap is set to it's hp at the start.
    bossMaxHp = bossHp;
  }

  public int hitHero() {
    return hitHero;
  }

  public int getBossStr() {
    return bossStr;
  }

  public int getBossHp() {
    return bossHp;
  }

  public int getBossMaxHp() {
    return bossMaxHp;
  }

  public String getBossName() {
    return bossName;
  }

  /** This method is how damage to the boss is calculated.
  */
  public int partyAttack(ArrayList<Hero> party) {
    int partyStr = 0;
    for (int i = 0; i < party.size(); i ++) {
      partyStr += party.get(i).getHeroStr();
    }
    return partyStr;
  }

  /** This method deals damage to the boss's Hp.
  */
  public void heroDmg(int partyDmg) {
    bossHp -= partyDmg;
  }

  /** This method allows the boss to be healed.
    */
  public void bossHeal(int bossGain) {
    bossHp += bossGain;
  }

  int ctr = 1;

  /** This method decides if the player is informed that the boss is bloodied.
    */
  public int stateCtr() {
    return ctr;
  }

  /** This method reduces the ctr by the given value to reduce it below 1.
    */
  public void bossState(int bloodied) {
    ctr -= bloodied;
  }

  /** [Developer method] This method is for the programmer to check that the
    * stats of the Boss have been properly established.
    */
  public void printBoss(ArrayList<Boss> bossLook) {
    for (int i = 0; i < bossLook.size(); i++) {
      System.out.print(bossLook.get(i).getBossName() + " [" + bossLook.get(i).getBossStr()
                        + " | " + bossLook.get(i).getBossHp() + "/"
                        + bossLook.get(i).getBossMaxHp() + "]\n");
    }
  }

  /** This method is how the party is healed.
    */
  public int partyHeal(ArrayList<Hero> party) {
    int groupHeal = 0;
    for (int i = 0; i < party.size(); i ++) {
      groupHeal += (party.get(i).getHeroHeal() / party.size());
    }
    return groupHeal;
  }

  /** This method adds the healing to the party's current hp.
    */
  public void healRound(ArrayList<Hero> stats) {
    for (int i = 0; i < stats.size(); i++) {
      //System.out.println("Your party heals for " + partyPlus + "damage!\n");
      Random roll = new Random();
      stats.get(i).healDmg(roll.nextInt(partyHeal(stats)));
    }
  }

  /** This method prevents overheal beyond the permitted value.
    */
  public void fixHealth(ArrayList<Hero> party) {
    for (int j = 0; j < party.size(); j++) {
      int current = party.get(j).getHeroHp();
      int maxHp = party.get(j).getHeroMaxHp();
      if (current > maxHp) {
        int strDmg = (current - maxHp);
        //int max = stats.get(j).getHeroMaxHp();
        //int current = stats.get(j).getHeroHp();
        party.get(j).bossDmg(strDmg);
      }
    }
  }

  /** This method runs the random attacks of the bosses for each round of
    * combat that is run.
    */
  public void bossAttack(ArrayList<Hero> party) {
    ArrayList<Integer> deadHeroes = new ArrayList<Integer>();

    // Spider Queen
    if (bossId == 0) {
      Random random = new Random();
      int randAttack = random.nextInt(6);

      // SQ Basic attack
      if (randAttack == 0 || randAttack == 1 || randAttack == 2) {
        int randHero = random.nextInt(party.size());
        int strDmg = random.nextInt(getBossStr());
        party.get(randHero).bossDmg(strDmg);
        System.out.println("The " + getBossName() + " strikes the "
                            + party.get(randHero).getHeroClass() + " for "
                            + strDmg + " damage!");

      // SQ Group attack
      } else if (randAttack == 3 || randAttack == 4) {
        System.out.println("The " + getBossName() + " sprays poison and strikes the entire party!");
        for (int i = 0; i < party.size(); i++) {
          int strDmg = random.nextInt(getBossStr());
          party.get(i).bossDmg(strDmg);
          System.out.println(party.get(i).getHeroClass() + " took "
                              + strDmg + " damage!");
        }

      // SQ Special attack
      } else if (randAttack == 5) {
        int randHero = random.nextInt(party.size());
        int decrStr = (random.nextInt(1) + 1);
        party.get(randHero).dmgStr(decrStr);
        System.out.println("The " + getBossName() + " bites the "
                            + party.get(randHero).getHeroClass()
                            + " and has weakened them!");
        if (party.get(randHero).getHeroStr() < 0) {
          party.get(randHero).strSetter();
        }
      }

    // Shadow Prince
    } else if (bossId == 1) {
      int randAttack = random.nextInt(6);

      // SP Basic attack
      if (randAttack == 0 || randAttack == 1 || randAttack == 2) {
        int randHero = random.nextInt(party.size());
        int strDmg = random.nextInt(getBossStr());
        party.get(randHero).bossDmg(strDmg);
        System.out.println("The " + getBossName() + " strikes "
                            + party.get(randHero).getHeroClass() + " for "
                            + strDmg + " damage!");

      // SP Group attack
      } else if (randAttack == 3 || randAttack == 4) {
        System.out.println("The " + getBossName() + " strikes the entire party from the shadows!");
        for (int i = 0; i < party.size(); i++) {
          int strDmg = random.nextInt(getBossStr());
          party.get(i).bossDmg(strDmg);
          System.out.println(party.get(i).getHeroClass() + " took "
                              + strDmg + " damage!");
        }

      // SP Special attack
      } else if (randAttack == 5) {
        int randHero = random.nextInt(party.size());
        int strDmg = random.nextInt(getBossStr());
        party.get(randHero).bossDmg(strDmg);
        bossHeal(strDmg);
        System.out.println("The " + getBossName() + " steals " + strDmg
                            + " health from the "
                            + party.get(randHero).getHeroClass() + "!");

      }

    // Dragon Lord
    } else if (bossId == 2) {
      int randAttack = random.nextInt(6);

      // DL Basic attack
      if (randAttack == 0 || randAttack == 1 || randAttack == 2) {
        int randHero = random.nextInt(party.size());
        int strDmg = random.nextInt(getBossStr());
        party.get(randHero).bossDmg(strDmg);
        System.out.println("The " + getBossName() + " strikes "
                            + party.get(randHero).getHeroClass() + " for "
                            + strDmg + " damage!");

      // DL Group attack
      } else if (randAttack == 3 || randAttack == 4) {
        System.out.println("The " + getBossName() + " engulfs the entire party in flames!");
        for (int i = 0; i < party.size(); i++) {
          //System.out.println("Your party heals for " + partyPlus + "damage!\n");
          int strDmg = random.nextInt(getBossStr());
          party.get(i).bossDmg(strDmg);
          System.out.println(party.get(i).getHeroClass() + " took "
                              + strDmg + " damage!");
        }

      // DL Special attack
      } else if (randAttack == 5) {
        //System.out.println("special attack");
        int randHero = random.nextInt(party.size());
        int decrHealth = (random.nextInt(10) + 11);
        party.get(randHero).dmgHealth(decrHealth);
        fixHealth(party);
        System.out.println("The " + getBossName() + " inflicts a mortal wound upon the "
                            + party.get(randHero).getHeroClass() + "!");
      }
    }
  }

  /** This method activates when the user attempts the 'run' command. It is more
    * for flavor than actually accomplishing anything in the game.
    */
  public void run(ArrayList<Hero> party) {
    //Boss boss = new Boss();
    Random chance = new Random();
    int randHero = chance.nextInt(party.size());
    int runTry = chance.nextInt(4);
    if (runTry == 0 || runTry == 1 || runTry == 2) {
      System.out.println("Escape failed...");
      System.out.println("The blocks your party's path"
                          + " and takes the opportunity to attack!");
      int failDmg;
      failDmg = ((3 * chance.nextInt(10)) + 10);
      party.get(randHero).bossDmg(failDmg);
      System.out.println("The " + getBossName() + " does " + failDmg + " damage to "
                          + party.get(randHero).getHeroClass() + "!\n");
      killHero(party);
    } else if (party.size() == 1) {
      System.out.println("Your party member escapes with their life, but not with glory...");
      System.out.println("GAME OVER");
      party.clear();
    } else {
      System.out.println("You escape with your lives, but not with glory...");
      System.out.println("GAME OVER");
      party.clear();
    }
  }

  /** This method removes heroes who have died from the party.
    */
  public void killHero(ArrayList<Hero> party) {
    for (int i = 0; i < party.size(); i++) {
      if (party.get(i).getHeroHp() <= 0) {
        System.out.println(party.get(i).getHeroClass() + " has died!");
        party.remove(i);
        i = 0;
        if (party.size() <= 0) {
          System.out.println("\nYour party is vanquished...");
          System.out.println("GAME OVER");
          break;
        }
      }

    }
  }
}
