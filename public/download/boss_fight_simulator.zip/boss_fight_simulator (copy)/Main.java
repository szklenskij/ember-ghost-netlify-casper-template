package project;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

  //int partySize = 0;
  /** This Main uses methods to run the Boss Fight Simulator.
    */
  public static void main(String [] args) {


    // Introduction to the program.
    System.out.println("\n\n\nWelcome to the Boss Fight Simulator, \nwhere you "
                        + "skip right to the good part of any dungeon grind.");
    System.out.println("\nLet's meet our heroes...");

    System.out.println( "\n [1] Knight    -- Good Attack, High Health, Minimal Heal"
                      + "\n [2] Wizard    -- High Attack, Low Health, Low Heal"
                      + "\n [3] Healer    -- Minimal Attack, Low Health, High Heal"
                      + "\n [4] Rogue     -- High Attack, Good Health, Minimal Heal"
                      + "\n [5] Barbarian -- Good Attack, High Health, Minimal Heal"
                      + "\n [6] Ranger    -- Good Attack, Good Health, Good Heal\n\n");
    System.out.println("\nPick four (4) heroes by their ID numbers to add to your"
                        + " party and challenge the boss...\n");


    ArrayList<Hero> party = new ArrayList<Hero>();
    ArrayList<Boss> bossStats = new ArrayList<Boss>();

    Boss boss = new Boss();
    bossStats.add(boss);

    Scanner input = new Scanner(System.in);

    // Player/User picks the 'Heroes' in their 'party'.
    int partySize = 0;
    while (true) {
      // Scanner scanner = new Scanner(System.in);
      int id;
      id = input.nextInt();
      // String heroSel = scanner.next();
      if (id >= 1 && id <= 6) {
        //id --;
        party.add(new Hero((id - 1)));
        partySize ++;
        System.out.println("Enter the next hero ID: ");
      } else {
        System.out.println("\n(!) That option is not vaild (!)\n");
      }
      if (partySize == 4) {
        break;
      }
    }

    // Announces the random boss to the player
    System.out.println("\n\nYour mighty heroes bare down on the stronghold of the "
                      + "boss.\nBefore them stands the terrible " + boss.getBossName()
                      + "\nready to tear them appart!");



    // Displays options for combat
    System.out.println("\n\nWhat do you command your party to do?"
                        + "\n[Attack] [Heal] [Party] [Run] [Quit]");

    // Combat rounds last as long as at least 1 party member is alive
    while (party.size() >= 1) {
      Scanner scan = new Scanner(System.in);
      String command = scan.nextLine().toLowerCase();
      // Attack command
      if (command.charAt(0) == 'a') {
        Random roll = new Random();
        System.out.println("Your party attacks..." );
        int partyDmg = roll.nextInt(boss.partyAttack(party));
        System.out.println("Your party hits the " + boss.getBossName() + " for "
                            + partyDmg + " damage!\n");
        boss.heroDmg(partyDmg);
        // Condition for victory, if boss hp goes below 0
        if (boss.getBossHp() <= 0) {
          System.out.println("\nWith one final blow, the " + boss.getBossName()
                              + " lies dead at your party's feet...\n");
          System.out.println("VICTORY!");
          break;
          //bossStats.clear();
        }
        // Informs player that the boss is now below 1/2 health
        if (boss.stateCtr() == 1) {
          int currentHealth = boss.getBossHp();
          int maxHealth = boss.getBossMaxHp();
          int bloodied = (maxHealth / 2);
          if (currentHealth <= bloodied) {
            System.out.println("The " + boss.getBossName() + " is bloodied!");
            boss.bossState(1);
          }
        }
        boss.bossAttack(party);
        boss.killHero(party);

      // Heal command
      } else if (command.charAt(0) == 'h') {
        System.out.println("Your party heals themselves...");
        boss.healRound(party);
        boss.fixHealth(party);
        boss.bossAttack(party);
        boss.killHero(party);

      // Check status of party
      } else if (command.charAt(0) == 'p') {
        System.out.print("      \t\t[Str | HP]\n");
        printParty(party);

      // Run command
      } else if (command.charAt(0) == 'r') {
        boss.run(party);

      // Developer helper, checks boss stats
      //} else if (command.charAt(0) == 'b') {
      //  boss.printBoss(bossStats);

      // Quit option
      } else if (command.charAt(0) == 'q') {
        if (party.size() == 1) {
          System.out.println("Your party member escapes with their life, but not with glory...");
          System.out.println("GAME OVER");
          party.clear();
        } else {
          System.out.println("You escape with your lives, but not with glory...");
          System.out.println("GAME OVER");
          party.clear();
        }
      } else {
        System.out.println("\n(!) That option is not vaild (!)\n");
      }
    }
  }


  // This prints the current status of the party
  private static void printParty(ArrayList<Hero> stats) {
    for (int i = 0; i < stats.size(); i++) {
      if (stats.get(i).getHeroId() == 4) {
        System.out.print(stats.get(i).getHeroClass() + "\t [" + stats.get(i).getHeroStr()
                          + " | " + stats.get(i).getHeroHp() + "/"
                          + stats.get(i).getHeroMaxHp() + "]\n");
      } else {
        System.out.print(stats.get(i).getHeroClass() + "\t\t [" + stats.get(i).getHeroStr()
                          + " | " + stats.get(i).getHeroHp() + "/"
                          + stats.get(i).getHeroMaxHp() + "]\n");
      }
    }
    System.out.println();
  }


}
